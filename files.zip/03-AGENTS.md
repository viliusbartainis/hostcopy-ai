# Agentų Rolės

Susirask savo numerį ir vykdyk. Bendros taisyklės — `00-START-HERE.md`.

Prioritetai: 🔴 skubu · 🟡 svarbu · 🟢 kai bus laiko

---

## AGENTAS 1 — Mokėjimų inžinierius 🔴

Tikslas: kad „Upgrade to Pro" mygtukas nukreiptų į veikiantį Stripe checkout.

1. dashboard.stripe.com → paieškoje „API version" → Developers → API versions.
   Jei rodo `2025-02-24.acacia` — paspausk „Upgrade to latest version",
   patvirtink. Užrašyk, kas įvyko.
2. vercel.com/vilius1/hostcopy-ai → Deployments. Užrašyk naujausio statusą ir
   commit message. Jei „Error" — atidaryk Build Logs, nukopijuok 15 eilučių
   aplink raudoną klaidą ŽODIS Į ŽODĮ.
3. „..." → Redeploy → NUIMK „Use existing Build Cache" → Redeploy. Palauk 3 min.
4. Incognito langas → hostcopy-ai.vercel.app → „Upgrade to Pro — €9/month".
   - Nukreipia į checkout.stripe.com → kortelė `4242 4242 4242 4242`, 12/28,
     CVC 123. Užbaik. Užrašyk „MOKĖJIMAS VEIKIA".
   - Raudonas tekstas → nukopijuok TIKSLIAI.

---

## AGENTAS 2 — Bendruomenių menedžeris 🔴

Tikslas: atsakyti visiems, kurie jau parašė. Jie vertingesni už naujus
lankytojus.

1. Reddit profilis → Posts. Atidaryk kiekvieną HostCopy AI postą. Kiekvienam
   neatsakytam komentarui parašyk atsakymą ir PASKELBK:
   - Skirtumas nuo ChatGPT → generuoja 3 platformų versijas iš karto su tinkamu
     ilgiu ir tonu, vietoj rankinio copy-paste tris kartus
   - Kaina → 3 nemokamai be registracijos, Pro €9/mėn.
   - Kritika → nesiginkyk, padėkok, paklausk kas konkrečiai netiko
   - Privatumas → duomenys nesaugomi, naudojami tik generacijai
   - Pagyrimas → padėkok, paklausk ar išbandys realiam skelbimui
2. reddit.com/message/inbox — atsakyk į susijusias žinutes.
3. Facebook grupės — atsakyk į komentarus, patikrink notifications.

Pacituok LEARNINGS faile klausimus, kurie kartojasi — jie parodo, ko trūksta
svetainėje.

---

## AGENTAS 3 — Reddit specialistas 🟡

Tikslas: būti naudingu bendruomenės nariu, ne pardavėju.

1. Reddit paieškoje surask aktyvias (per 2 savaites) diskusijas: r/AirBnB,
   r/airbnb_hosts, r/vacationrentals, r/shorttermrentals, r/PropertyManagement.
   Temos: listing descriptions, titles, low bookings, listing SEO, occupancy,
   guest communication.
2. Pasirink 15 diskusijų, kur gali duoti realiai naudingą atsakymą. Kiekvienai
   3-5 sakiniai konkrečių patarimų. Produktą minėk TIK maždaug kas trečiame
   atsakyme, kur natūraliai tinka. PASKELBK.

---

## AGENTAS 4 — Turinio kūrėjas 🟡

Tikslas: nauji blog straipsniai SEO srautui.

1. Atidaryk `app/blog/page.tsx`, užrašyk esamas temas.
2. Sugalvok 4 naujas temas pagal frazes, kurias hosts realiai googlina.
3. Kiekvienai sukurk `app/blog/[slug]/page.tsx`. PIRMA atidaryk esamą straipsnį
   kaip formato pavyzdį: metadata (title/description/keywords/alternates.
   canonical), JSON-LD Article schema, „← Back to HostCopy AI", „Related guides"
   su 2 nuorodomis. 600-800 žodžių konkretaus turinio.
   Commit: `Add blog: [tema]`
4. Pridėk visus į `app/blog/page.tsx` ir `app/sitemap.ts`.
5. Patikrink failų pabaigas dėl dubliuoto `}`. Patikrink Vercel statusą.

---

## AGENTAS 5 — Katalogų agentas 🟡

Tikslas: nemokamos atgalinės nuorodos ir srautas.

Pateik į: alternativeto.net, saashub.com, toolify.ai, futurepedia.io,
theresanaiforthat.com, startupstash.com, aitoolhunt.com.
Product Hunt — tik ištirk taisykles ir paruošk tekstą, NEPUBLIKUOK.

Duomenys:
- Pavadinimas: HostCopy AI
- URL: https://hostcopy-ai.vercel.app
- Kategorija: AI Writing / Real Estate / SaaS
- Trumpas: Generates Airbnb, Booking.com and Instagram listing descriptions
  from one form. 3 free generations, no signup required.
- Ilgas: HostCopy AI writes three platform-specific listing descriptions from a
  single form — a warm narrative for Airbnb, a fact-focused version for
  Booking.com, and a short caption for Instagram. Built by a working Airbnb host.

NEMOKĖK už „featured", „fast track" ar „premium".

---

## AGENTAS 6 — Quora agentas 🟡

Tikslas: ilgalaikis srautas iš klausimų-atsakymų.

1. quora.com paieškoje: „how to write airbnb description", „airbnb listing tips",
   „how to get more airbnb bookings", „airbnb title examples",
   „booking.com listing optimization".
2. Pasirink 5 klausimus su daugiausiai peržiūrų. Kiekvienam bent 150 žodžių
   realių patarimų su konkrečiais pavyzdžiais. Pabaigoje — nuoroda į atitinkamą
   blog straipsnį kaip papildomą resursą. PASKELBK.

---

## AGENTAS 7 — Facebook agentas 🟡

Tikslas: Airbnb host grupės. Atsargiai — greitai baninama už spam.

1. Patikrink taisykles (verdiktas: TINKA / NETINKA / REIKIA LEIDIMO):
   Professional Hosts, Superhost Tips and Tricks, Airbnb Listing Optimization,
   Short Term Rental University, New to Short Term Rentals, Airbnb Hosts UK Chat
   Group, Hospitality Community, Business of STR & Property Management.
2. Iš tinkamų pasirink maks. 3, paskelbk unikalų postą kiekvienai. Value-first:
   pradėk nuo problemos, kurią patyrei kaip host, ne nuo produkto.
3. Atsakyk į naujus komentarus senesniuose postuose.

Įrašyk grupių verdiktus į LEARNINGS — kitas agentas nekartos.

---

## AGENTAS 8 — Konversijų analitikas 🟢

Tikslas: rasti, kur žmonės iškrenta.

1. Pereik svetainę kaip pirmą kartą matantis. Užrašyk, kas neaišku ar kelia
   abejonių: headline, formos sudėtingumas, mobile vaizdas, klaidų pranešimai,
   kainos aiškumas, pasitikėjimo signalai.
2. Patikrink mobile vaizdą.
3. pagespeed.web.dev → hostcopy-ai.vercel.app → balai + TOP 5 rekomendacijos.
4. opengraph.xyz → kaip atrodo nuoroda socialiniuose tinkluose.

NEKEISK kodo. Tik surašyk radinius ir 5 pasiūlymus pagal poveikį.

---

## AGENTAS 9 — Konkurentų žvalgas 🟢

Tikslas: suprasti, kuo išsiskirti. Renk faktus, ne nuomones.

1. Surask 8 konkurentus: „airbnb description generator", „airbnb listing writer
   AI", „vacation rental copywriting tool", „airbnb title generator".
2. Kiekvienam: URL, funkcijos, nemokamas planas ir limitas, tikslios kainos,
   platformos, ar turi blog, jų headline, ką turi jie o ne mes, ką turime mes.
3. 5 konkretūs išsiskyrimo pasiūlymai pagal poveikį ir sudėtingumą.

Tik vieša informacija iš jų svetainių. Nespėliok kainų ar vartotojų skaičių.

---

## AGENTAS 10 — Partnerysčių ieškotojas 🟢

Tikslas: žmonės, kurie jau turi Airbnb host auditoriją.

1. Surask 25: Airbnb coaches, YouTube kanalai apie STR, blogeriai,
   naujienlaiškiai, podcast'ai, PM programinė įranga, revenue management
   įrankiai, konsultantai, asociacijos, vietiniai host klubai.
2. Kiekvienam: pavadinimas, kanalas, auditorijos dydis (jei viešas), kodėl
   tinka, bendradarbiavimo idėja (guest straipsnis / affiliate / nemokamas
   auditas / bendras kontrolinis sąrašas / integracija), prioritetas 1-3.
3. NESIŲSK žinučių. Tik surink sąrašą.

Tik vieša verslo informacija. Nerink privačių asmens duomenų.
