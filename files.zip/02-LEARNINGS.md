# Ko Išmokta

**Šis failas yra sistemos atmintis.** Kiekvienas agentas prieš darbą jį skaito,
po darbo — papildo. Rašyk konkrečiai: ne „buvo problemų", o „X neveikė, nes Y,
sprendimas — Z".

---

## TECHNINĖS PAMOKOS

**Dubliuotas `}` failo pabaigoje laužo build.**
Kelis kartus redaguojant blog straipsnius per GitHub web UI, failo gale likdavo
papildomas uždarantis skliaustelis. Rezultatas — visas Vercel build žlunga, ir
svetainė serveruoja seną versiją. Po kiekvieno commit'o būtina patikrinti failo
pabaigą.

**`package.json` ir `package-lock.json` turi būti keičiami kartu.**
Pridėjus priklausomybę tik į `package.json` per GitHub web UI, Vercel meta
„Module not found". `package-lock.json` yra ~6700 eilučių, jo negalima saugiai
redaguoti rankiniu būdu — reikia įkelti (upload) paruoštą failą.

**JSX skliaustų tvarka svarbi.**
Įterpiant naują bloką prieš `)}`, `</div>` turi eiti PRIEŠ `)}`, ne po jo.
Neteisinga tvarka duoda „Unterminated regexp literal" klaidą.

**Vercel build cache slepia pataisymus.**
Po Environment Variables pakeitimo ar priklausomybių atnaujinimo būtina
Redeploy su NUIMTA „Use existing Build Cache" varnele. Kitaip veikia sena
versija ir atrodo, kad pataisymas nepadėjo.

**Environment Variables neveikia atgaline data.**
Pridėjus naują kintamąjį, senas deployment jo nemato. Reikia naujo deploy.

**Gyva svetainė gali rodyti seną kodą.**
Jei matai klaidą, kurios kode jau nebėra — pirmiausia patikrink Vercel
Deployments statusą. Jei paskutinis „Error", serveruojama ankstesnė versija.

**Groq modelis keitėsi.**
`llama-3.3-70b-versatile` nebeveikia (deprecated 2026-06-17). Dabartinis:
`openai/gpt-oss-120b` — reikalauja `max_tokens: 2000` ir
`reasoning_effort: 'low'` kartu su `response_format: json_object`.

**Dark mode lauždavo įvesties laukus.**
Balta ant balto. Sprendimas: `color-scheme: light` faile `globals.css`.

---

## KONVERSIJOS PAMOKOS

**Limito pranešimas buvo didžiausia klaida.**
Kai žmogus išnaudodavo 3 nemokamas generacijas — didžiausio pirkimo noro
momentas — svetainė rodydavo „Pro plan coming soon, check back shortly". Tai
tiesiogine prasme sakė „ateik kitą kartą" tada, kai žmogus buvo pasiruošęs
mokėti. Pakeista į matomą upgrade bloką su mygtuku.

**Mygtukas po rezultatais buvo per žemai.**
Žmonės jo nematydavo. Perkeltas prie generavimo mygtuko, kur žvilgsnis jau yra.

---

## MARKETINGO PAMOKOS

*(Kol kas tuščia — pirmas marketingo agentas užpildys)*

Rašyk čia: kurie subreddit'ai priėmė/atmetė, kokie tekstai sulaukė reakcijos,
kurios Facebook grupės reikalauja admin leidimo, kurie katalogai priėmė be
mokėjimo, kokie klausimai kartojasi komentaruose.

---

## PROCESO PAMOKOS

**Claude for Chrome turi 5 val. limitą.**
Ilgos sesijos nutrūksta pusiaukelėje. Todėl užduotys turi būti suskirstytos
prioritetų tvarka — svarbiausia pirma.

**Agentas negali savarankiškai debug'inti.**
Kai Chrome bandė pats taisyti build klaidas, atsirasdavo naujų. Taisyklė:
agentas nukopijuoja tikslų klaidos tekstą ir perduoda, o ne spėlioja.

**Tikslus klaidos tekstas yra viskas.**
„Neveikia" arba „buvo klaida" nieko neduoda. Reikia žodis į žodį nukopijuoto
teksto iš ekrano arba Build Logs.

---

## KAIP PAPILDYTI ŠĮ FAILĄ

Atidaryk GitHub'e (pieštuko ikona), pridėk naują punktą tinkamoje skiltyje.
Formatas: **Trumpa antraštė paryškintai.** Tada 1-3 sakiniai: kas neveikė,
kodėl, koks sprendimas.
Commit message: `Add learnings from Agent [N] session`
