# Projekto Būklė

**Paskutinį kartą atnaujinta:** 2026-08-06

---

## ✅ PADARYTA

**Techninė bazė**
- Svetainė veikia, build praeina švariai
- 18 blog straipsnių
- SEO: sitemap, robots.txt, Article/FAQ/Organization schema, canonical URL,
  dinaminis OG paveikslėlis
- Blog indeksas su visų straipsnių sąrašu
- 404 puslapis
- „Copied!" vizualus patvirtinimas
- Formos validacija
- Vercel Web Analytics

**Konversija**
- Nemokamo limito išsaugojimas (localStorage) — nebegalima apeiti atnaujinus
  puslapį
- Kai limitas išnaudotas — rodomas geltonas „Upgrade to Pro" blokas su mygtuku
- Matomi klaidų pranešimai vietoj tylaus žlugimo

**Marketingas**
- Reddit r/AirBnBHosts postas paskelbtas
- Facebook grupės postas paskelbtas
- Dalis komentarų atsakyta

**Stripe**
- Paskyra sukurta (Sandbox/Test režimas)
- Produktas „HostCopy AI Pro" €9/mėn. sukurtas
- `app/api/checkout/route.ts` sukurtas
- Environment Variables įrašyti Vercel

---

## 🔴 BLOKUOJA (svarbiausia)

**Stripe checkout neveikia.**

Klaida, rodoma paspaudus „Upgrade to Pro":
```
Managed Payments is not supported on API version 2025-02-24.acacia.
Update your API version, or set the API Version of this request to
2025-03-31.basil or greater.
```

Kas jau bandyta:
- Kode nurodyta `apiVersion: '2026-07-29.dahlia'` — commit'inta į main
- Build praeina lokaliai švariai

Kas įtariama:
- Vercel deploy žlunga, todėl gyva svetainė serveruoja seną kodą
- ARBA Stripe paskyros numatytoji API versija vis dar užrakinta ties acacia

Ko reikia:
1. Stripe dashboard → Developers → API versions → atnaujinti versiją
2. Vercel Deployments → tikslus build klaidos logas, jei statusas „Error"

---

## ⏳ LAUKIA VILIAUS (agentai negali)

- Stripe perjungimas iš Sandbox į Live režimą
- Live režime: banko sąskaita (IBAN), asmens duomenys, galimai ID
- Live produkto sukūrimas ir naujų raktų įrašymas į Vercel
- Google Search Console prijungimas (pagreitintų indeksavimą)

---

## 📋 EILĖJE

- Reddit value-first atsakymai svetimose diskusijose
- Quora atsakymai
- Naujos Facebook grupės
- Nemokami katalogai (alternativeto, saashub, toolify ir kt.)
- Nauji blog straipsniai
- Konkurentų analizė
- Partnerysčių sąrašas

---

## KAIP ATNAUJINTI ŠĮ FAILĄ

Baigęs darbą, atidaryk šį failą GitHub'e (pieštuko ikona), perkelk atliktus
punktus į „PADARYTA", atnaujink „BLOKUOJA" ir „EILĖJE", pakeisk datą viršuje.
Commit message: `Update status after Agent [N] session`
