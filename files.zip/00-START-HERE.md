# HostCopy AI — Agentų Centras

**Kiekvienas agentas PRIVALO perskaityti šį failą prieš pradėdamas darbą.**

Bazinis URL failams skaityti:
`https://raw.githubusercontent.com/viliusbartainis/hostcopy-ai/main/agents/`

## Skaitymo tvarka kiekvienai sesijai

1. `00-START-HERE.md` (šis failas) — kontekstas ir taisyklės
2. `01-STATUS.md` — kas jau padaryta, kas vyksta dabar
3. `02-LEARNINGS.md` — ko išmokta iš ankstesnių sesijų (KRITIŠKAI SVARBU)
4. `03-AGENTS.md` — tavo konkreti rolė ir užduotys

## Rašymo pareiga (taip sistema mokosi)

Baigęs darbą, PRIVALAI atnaujinti du failus per GitHub:
- `01-STATUS.md` — ką padarei, ką reikia toliau
- `02-LEARNINGS.md` — ką sužinojai, kas neveikė, ko vengti kitą kartą

Be šito kitas agentas kartos tas pačias klaidas.

---

## PRODUKTO KONTEKSTAS

- **Produktas:** HostCopy AI — https://hostcopy-ai.vercel.app
- **Ką daro:** AI generuoja Airbnb, Booking.com ir Instagram skelbimų
  aprašymus iš vienos formos
- **Kaina:** 3 generacijos nemokamai be registracijos, Pro €9/mėn.
- **Kūrėjas:** Airbnb host iš Vilniaus, sukūrė įrankį sau
- **Blog:** hostcopy-ai.vercel.app/blog
- **GitHub:** github.com/viliusbartainis/hostcopy-ai (branch `main`, commit tiesiai)
- **Vercel:** vercel.com/vilius1/hostcopy-ai
- **Tikslas:** pirmi mokantys klientai

## BENDROS TAISYKLĖS (galioja visiems agentams)

**Darbo higiena:**
- Prieš kiekvieną žingsnį patikrink, ar jis jau atliktas. Jei taip — praleisk.
- Jei žingsnis nepavyksta 2 kartus — praleisk, užrašyk „nepavyko", tęsk toliau.
  Nestrigk viename dalyke.
- Nesakyk, kad kažkas veikia, jei realiai nepatikrinai naršyklėje.

**Kur privalai sustoti:**
- CAPTCHA, 2FA, telefono patvirtinimas
- Banko duomenys, IBAN, mokėjimo kortelė
- Asmens kodas, gimimo data, ID dokumento nuotrauka
- Slaptažodžių ar saugumo nustatymų keitimas

Tokiu atveju: SUSTOK tame žingsnyje, užrašyk „reikia Viliaus", tęsk kitus.

**Sąžiningumas:**
- Jokių išgalvotų atsiliepimų, netikrų vartotojų skaičių ar statistikų
- Jokių garantijų dėl rezervacijų, SEO reitingų ar pajamų
- Neslėpk, kad esi susijęs su produktu

**Skelbimai bendruomenėse:**
- Prieš KIEKVIENĄ vietą pirma perskaityk taisykles (Rules/About)
- Jei draudžia self-promotion arba reikia admin leidimo — PRALEISK
- Kiekvienai vietai unikalus tekstas, niekada nekartok to paties
- Value-first: pirmiausia išspręsk problemą, produktą minėk tik jei tinka

**Kodo darbas:**
- Po kiekvieno commit'o patikrink failą GitHub'e
- Ypač: ar failo pabaigoje NĖRA dubliuoto `}` simbolio (dažna klaida,
  laužianti build)
- Po commit'ų patikrink Vercel Deployments statusą
- Jei „Error" — nukopijuok 15 eilučių aplink raudoną klaidą iš Build Logs
